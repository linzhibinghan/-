# GI Json Files Json_Integration

![image](https://user-images.githubusercontent.com/82816129/230099550-51500c23-7641-48df-950f-a6a1d35553e1.png)

### [戳我下载最新版本](https://github.com/Xcating/Json_Integration/archive/refs/heads/main.zip)

---

[#]Most of the source files come from 'Sam5440' .

[#] Thank you for providing some JSON files from "Holding Green Umbrella".

[#] Thank you for the JSON and dog food files provided by "AXC00".

[#]tky, GodWil, for providing the treasure chest/exploration documents and mourning

[#]Thank you to "Misuki" for providing the 3.6 map files.

[#]Thank you "情与宇宇热恋"
